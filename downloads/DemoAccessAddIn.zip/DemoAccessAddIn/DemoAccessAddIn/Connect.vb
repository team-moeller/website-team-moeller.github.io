﻿imports Extensibility
imports System.Runtime.InteropServices
Imports Access = Microsoft.Office.Interop.Access
Imports Microsoft.Office.Core

#Region " Read me for Add-in installation and setup information. "
' When run, the Add-in wizard prepared the registry for the Add-in.
' At a later time, if the Add-in becomes unavailable for reasons such as:
'   1) You moved this project to a computer other than which is was originally created on.
'   2) You chose 'Yes' when presented with a message asking if you wish to remove the Add-in.
'   3) Registry corruption.
' you will need to re-register the Add-in by building the DemoAccessAddInSetup project, 
' right click the project in the Solution Explorer, then choose install.
#End Region

'ToDo: GUID ersetzen
<GuidAttribute("3B915BC8-7FD5-4CF6-8217-90499551EFB7"), ProgIdAttribute("DemoAccessAddIn.Connect")> _
Public Class Connect
	
	Implements Extensibility.IDTExtensibility2
    Implements IRibbonExtensibility

    Public appAcc As Access.Application
    Private addInInstance As Object
	
	Public Sub OnBeginShutdown(ByRef custom As System.Array) Implements Extensibility.IDTExtensibility2.OnBeginShutdown

        Me.Dispose()

    End Sub
	
	Public Sub OnAddInsUpdate(ByRef custom As System.Array) Implements Extensibility.IDTExtensibility2.OnAddInsUpdate
	End Sub
	
	Public Sub OnStartupComplete(ByRef custom As System.Array) Implements Extensibility.IDTExtensibility2.OnStartupComplete
	End Sub
	
	Public Sub OnDisconnection(ByVal RemoveMode As Extensibility.ext_DisconnectMode, ByRef custom As System.Array) Implements Extensibility.IDTExtensibility2.OnDisconnection
	End Sub
	
	Public Sub OnConnection(ByVal application As Object, ByVal connectMode As Extensibility.ext_ConnectMode, ByVal addInInst As Object, ByRef custom As System.Array) Implements Extensibility.IDTExtensibility2.OnConnection

        appAcc = DirectCast(application, Access.Application)
        addInInstance = addInInst

    End Sub

    Public Function GetCustomUI(ByVal RibbonID As String) As String Implements IRibbonExtensibility.GetCustomUI

        Return My.Resources.DemoAccessAddIn.rbnAddIn

    End Function

    Public Sub showForm(ByVal control As IRibbonControl)

        Dim frm As Form

        Select Case control.Id
            Case "btnDemoAddIn"
                frm = New frmDemoAddIn
            Case Else
                frm = Nothing
        End Select

        frm.ShowDialog()

    End Sub

    Protected Sub Dispose()

        '!!! Ohne GC.Collect schließt Access nicht und das Access-Fenster hängen.
        GC.Collect()
        GC.WaitForPendingFinalizers()

        'If appAcc IsNot Nothing Then
        '    MsgBox(appAcc.Name & " wird geschlossen")
        '    'eventuell um Marshal.ReleaseComObject erweitern.
        '    'in diesem BeispielComAddIn war es bei mir nicht notwendig.
        '    Try
        '        Runtime.InteropServices.Marshal.ReleaseComObject(appAcc)
        '    Finally
        '        appAcc = Nothing
        '    End Try
        'End If

    End Sub

End Class
